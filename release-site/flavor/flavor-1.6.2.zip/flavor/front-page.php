<?php
/**
 * Dynamic Restaurant Homepage — Assembles 15 Modular Enterprise Sections.
 *
 * @package Flavor
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Opt-in bespoke packs have their own composition; the seven legacy demos
// continue to use the original modular homepage below.
if ( \Flavor\Bespoke_Demos::active() ) {
	get_template_part( 'template-parts/demos/' . \Flavor\Design::current_skin() );
} else {

// 1. Hero Section
get_template_part( 'template-parts/marketing/hero' );

// 2. Intro & Highlights
get_template_part( 'template-parts/marketing/intro' );

// 3. Featured Chef's Specials
get_template_part( 'template-parts/marketing/featured' );

// 4. Categories Showcase Grid
get_template_part( 'template-parts/marketing/categories' );

// 5. Special Offers & Promo Banners
get_template_part( 'template-parts/marketing/special-offers' );

// 6. Table Reservation CTA Banner
get_template_part( 'template-parts/marketing/reservation-cta' );

// 7. About & Culinary Story
get_template_part( 'template-parts/marketing/about' );

// 8. Photo Gallery
get_template_part( 'template-parts/marketing/gallery' );

// 9. Guest Testimonials & Reviews
get_template_part( 'template-parts/marketing/testimonials' );

// 10. Working Hours & Location Details
get_template_part( 'template-parts/marketing/hours' );

}

// 11. Page Content (for Elementor / Gutenberg Custom Blocks)
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$has_post_content      = '' !== trim( (string) get_the_content() );
		$has_elementor_content = \Flavor\Elementor::has_builder_content( get_the_ID() );
		$has_flavor_builder    = ! empty( get_post_meta( get_the_ID(), \Flavor\Builder::META, true ) );
		if ( $has_post_content || $has_elementor_content || $has_flavor_builder ) {
			echo '<div class="flavor-container flavor-custom-page-content" style="padding-block: 40px;">';
			the_content();
			echo '</div>';
		}
	}
}

get_footer();

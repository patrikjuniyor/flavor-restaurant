<?php
/**
 * Bespoke, RTL-first demo landing pages. Only completed packs opt in.
 * Shared UI reads live WooCommerce products; it never simulates checkout.
 *
 * @package Flavor
 */

namespace Flavor;

defined( 'ABSPATH' ) || exit;

class Bespoke_Demos {
	/** Ready packs; legacy homepages remain untouched. */
	public const SLUGS = array( 'juice-bar', 'dark-luxe', 'minimal-clean', 'cloud-kitchen', 'catering' );

	public static function init(): void {
		add_filter( 'body_class', array( self::class, 'body_class' ) );
		add_action( 'customize_register', array( self::class, 'customizer' ) );
	}


	/**
	 * Copy bespoke-demos.js prints (the filter counter and the delivery-zone
	 * checker). Same rule as the other maps: the script holds no text of its own
	 * so that every label is translatable, and tests/theme/test-js-i18n.php
	 * checks the two sides against each other.
	 */
	public static function strings(): array {
		return array(
			'selection_shown' => __( '%s انتخاب نمایش داده می‌شود.', 'flavor' ),
			'zone_checking'   => __( 'در حال بررسی محله…', 'flavor' ),
			'zone_failed'     => __( 'بررسی محله ناموفق بود. دوباره تلاش کن یا تماس بگیر.', 'flavor' ),
			'zone_summary'    => __( '%1$s · هزینهٔ ارسال: %2$s · زمان برآوردی منطقه: حدود %3$s دقیقه؛ زمان تضمین‌شده نیست.', 'flavor' ),
			'zone_out'        => __( 'خارج از محدودهٔ ارسال؛ دریافت بیرون‌بر را بررسی کن.', 'flavor' ),
		);
	}
	public static function active(): bool {
		return in_array( Design::current_skin(), self::SLUGS, true );
	}

	/** @return array<string, mixed> */
	public static function demo(): array {
		static $packs = null;
		if ( null === $packs ) {
			require_once FLAVOR_DIR . '/inc/demo-catalog.php';
			$packs = flavor_demo_catalog();
		}
		$skin = Design::current_skin();
		return (array) apply_filters( 'flavor_bespoke_demo', $packs[ $skin ] ?? array(), $skin );
	}

	/** Copy can be overridden in the Customizer without editing templates. */
	public static function value( string $key, string $fallback = '' ): string {
		$demo    = self::demo();
		$default = $demo['landing'][ $key ] ?? $fallback;
		return (string) get_theme_mod( 'flavor_landing_' . $key, is_scalar( $default ) ? $default : $fallback );
	}

	public static function enabled( string $key ): bool {
		return 'no' !== get_theme_mod( 'flavor_landing_' . $key . '_enable', 'yes' );
	}

	/**
	 * Shipped placeholder for demo art that is not installed.
	 *
	 * @return string
	 */
	public static function placeholder(): string {
		return FLAVOR_URI . '/assets/img/demo-placeholder.svg';
	}

	/**
	 * Local, bundled media only; traversal and missing-image paths are rejected.
	 *
	 * The sellable theme ships without the 12 MB demo pack, so the file is
	 * often absent. Returning a URL that 404s renders a broken-image icon on
	 * the front page, which reads as a bug in the theme rather than as "install
	 * the demo pack". Missing art degrades to a bundled placeholder instead.
	 */
	public static function asset( string $file ): string {
		$file = sanitize_file_name( basename( $file ) );
		$skin = Design::current_skin();

		foreach ( array( $file, 'hero.jpg' ) as $candidate ) {
			if ( '' !== $candidate && is_readable( FLAVOR_DIR . '/demos/' . $skin . '/' . $candidate ) ) {
				return FLAVOR_URI . '/demos/' . $skin . '/' . $candidate;
			}
		}

		return self::placeholder();
	}

	public static function page_url( string $slug ): string {
		$page = get_page_by_path( $slug );
		return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
	}

	public static function action_url( string $action = 'menu' ): string {
		if ( 'phone' === $action ) {
			return 'tel:' . preg_replace( '/\D+/', '', (string) get_theme_mod( 'flavor_phone', self::demo()['phone'] ?? '' ) );
		}
		if ( 0 === strpos( $action, '#' ) ) {
			// Hiding the catering planner must not strand its primary CTA.
			if ( '#proposal' === $action && 'catering' === Design::current_skin() && ! self::enabled( 'feature' ) ) {
				$action = '#visit';
			}
			return home_url( '/' ) . $action;
		}
		return self::page_url( in_array( $action, array( 'menu', 'reservation', 'branches', 'contact' ), true ) ? $action : 'menu' );
	}

	public static function digits( string $value ): string {
		return strtr( $value, array( '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹' ) );
	}

	/**
	 * Match the live menu/cart display unit, not WooCommerce's unrelated
	 * default currency (often USD on a fresh development install).
	 *
	 * @param int|float|string $stored Product price in Core storage units.
	 */
	public static function price( $stored ): string {
		if ( class_exists( \FlavorCore\WooCommerce\Currency::class ) ) {
			return esc_html( \FlavorCore\WooCommerce\Currency::format( (int) round( (float) $stored ) ) );
		}
		return function_exists( 'wc_price' ) ? wc_price( $stored ) : esc_html( self::digits( (string) $stored ) );
	}

	/** Safe inline emphasis, not arbitrary markup from settings. */
	public static function hero_title(): string {
		$demo   = self::demo();
		$title  = (string) get_theme_mod( 'flavor_hero_title', $demo['hero_title'] ?? get_bloginfo( 'name' ) );
		$accent = self::value( 'hero_accent' );
		$pos    = '' !== $accent ? strpos( $title, $accent ) : false;
		if ( false === $pos ) {
			return esc_html( $title );
		}
		return esc_html( substr( $title, 0, $pos ) ) . '<em>' . esc_html( $accent ) . '</em>' . esc_html( substr( $title, $pos + strlen( $accent ) ) );
	}

	/** Decorative icons have no duplicate accessible names. */
	public static function icon( string $name, int $size = 22 ): void {
		$paths = array(
			'arrow'   => '<path d="M19 12H5m6-6-6 6 6 6"/>',
			'leaf'    => '<path d="M20 4C9 2 3 7 5 14c2 6 12 7 15-10Z"/><path d="M4 21 15 10M9 16v-5m0 5h5"/>',
			'bag'     => '<path d="M5 7h14l1 14H4L5 7Z"/><path d="M9 8V5a3 3 0 0 1 6 0v3"/>',
			'phone'   => '<path d="m7 3 3 5-2 2a15 15 0 0 0 6 6l2-2 5 3v3c-9 2-20-9-18-18l4 1Z"/>',
			'pin'     => '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
			'clock'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
			'check'   => '<path d="m5 12 4 4L19 6"/>',
			'plus'    => '<path d="M12 5v14M5 12h14"/>',
			'glass'   => '<path d="M6 5h12l-2 16H8L6 5ZM13 5l3-3"/><path d="M7 10h10"/>',
			'spark'   => '<path d="m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3 3-7Z"/>',
			'truck'   => '<path d="M2 5h12v12H2V5Zm12 4h4l4 5v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
			'calendar'=> '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 2v6m10-6v6M3 11h18"/>',
			'cloche'  => '<path d="M3 17h18M5 17a7 7 0 0 1 14 0M2 21h20M12 6v3"/><circle cx="12" cy="5" r="1"/>',
			'copy'    => '<rect x="8" y="8" width="12" height="13" rx="1"/><path d="M16 8V3H4v13h4"/>',
			'home'    => '<path d="m3 10 9-7 9 7v11h-6v-7H9v7H3V10Z"/>',
			'menu'    => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		);
		$size = max( 12, min( 64, $size ) );
		echo '<svg aria-hidden="true" focusable="false" width="' . esc_attr( (string) $size ) . '" height="' . esc_attr( (string) $size ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">';
		echo $paths[ $name ] ?? $paths['spark']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal trusted SVG.
		echo '</svg>';
	}

	/** @param string[] $classes @return string[] */
	public static function body_class( array $classes ): array {
		if ( self::active() ) {
			$classes[] = 'flavor-bespoke';
		}
		return $classes;
	}

	/** @param \WP_Customize_Manager $wp_customize Customizer. */
	public static function customizer( $wp_customize ): void {
		if ( ! self::active() ) {
			return;
		}
		$wp_customize->add_section( 'flavor_bespoke', array(
			'title'       => __( 'صفحه اختصاصی دمو', 'flavor' ),
			'description' => __( 'تیتر، تصویر اصلی، رنگ و فونت از بخش‌های معمول قالب قابل تغییرند. این بخش محتوای صفحه اختصاصی را کنترل می‌کند.', 'flavor' ),
			'priority'    => 38,
		) );
		$fields = array(
			'eyebrow'       => __( 'برچسب بالای تیتر', 'flavor' ),
			'hero_accent'   => __( 'عبارت برجسته در تیتر اصلی', 'flavor' ),
			'primary_label'=> __( 'متن دکمه اصلی', 'flavor' ),
			'menu_title'    => __( 'تیتر منوی منتخب', 'flavor' ),
			'story_title'   => __( 'تیتر داستان برند', 'flavor' ),
			'feature_title' => __( 'تیتر پیشنهاد اختصاصی', 'flavor' ),
			'feature_text'  => __( 'توضیح پیشنهاد اختصاصی', 'flavor' ),
			'visit_title'   => __( 'تیتر بخش تماس', 'flavor' ),
			'brand_caption'=> __( 'زیرعنوان لوگوی متنی', 'flavor' ),
		);
		if ( 'catering' === Design::current_skin() ) {
			$fields['services_title'] = __( 'تیتر خدمات پذیرایی', 'flavor' );
			$fields['services_text']  = __( 'توضیح خدمات پذیرایی', 'flavor' );
			$fields['menu_notice']    = __( 'توضیح مقدار و شرایط منوی کترینگ', 'flavor' );
		}
		foreach ( $fields as $key => $label ) {
			$id = 'flavor_landing_' . $key;
			$textarea = in_array( $key, array( 'feature_text', 'services_text', 'menu_notice' ), true );
			$wp_customize->add_setting( $id, array( 'default' => self::value( $key ), 'sanitize_callback' => $textarea ? 'sanitize_textarea_field' : 'sanitize_text_field' ) );
			$wp_customize->add_control( $id, array( 'label' => $label, 'section' => 'flavor_bespoke', 'type' => $textarea ? 'textarea' : 'text' ) );
		}
		foreach ( array( 'story' => 'داستان برند', 'process' => 'مراحل و ویژگی‌ها', 'feature' => 'پیشنهاد اختصاصی', 'faq' => 'پرسش‌های متداول' ) as $key => $label ) {
			$id = 'flavor_landing_' . $key . '_enable';
			$wp_customize->add_setting( $id, array( 'default' => 'yes', 'sanitize_callback' => static function ( $v ) { return 'no' === $v ? 'no' : 'yes'; } ) );
			$wp_customize->add_control( $id, array( 'label' => $label, 'section' => 'flavor_bespoke', 'type' => 'radio', 'choices' => array( 'yes' => __( 'نمایش', 'flavor' ), 'no' => __( 'پنهان', 'flavor' ) ) ) );
		}
		// `flavor_landing_story_image` is registered in Customizer::register()
		// instead. It also feeds the «دربارهٔ مجموعه» page template, which every
		// skin uses, so a demo-only control left the seven legacy skins with no
		// way to set that photo.
	}
}

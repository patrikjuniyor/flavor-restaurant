/**
 * Menu + modifiers + cart drawer + checkout. Vanilla JS, RTL-first.
 */
(function () {
	'use strict';

	var cfg = window.flavorData || {};
	var ui = window.FlavorUI;
	var grid = document.getElementById('flavor-menu-grid');
	if (!grid || !cfg.hasCore) {
		var st = document.getElementById('flavor-menu-status');
		if (st && !cfg.hasCore) st.textContent = (cfg.i18n && cfg.i18n.offline) || '';
		return;
	}

	var statusEl = document.getElementById('flavor-menu-status');
	var catsEl = document.getElementById('flavor-cats');
	var sheet = document.getElementById('flavor-sheet');
	var sheetTitle = document.getElementById('flavor-sheet-title');
	var sheetBody = document.getElementById('flavor-sheet-body');
	var sheetAdd = document.getElementById('flavor-sheet-add');
	var cartCount = document.getElementById('flavor-cart-count');
	var mobileCartCount = document.getElementById('flavor-mobile-cart-count');
	var cartLines = document.getElementById('flavor-cart-lines');
	var cartTotal = document.getElementById('flavor-cart-total');
	var cartPanel = document.getElementById('flavor-cart-panel');
	var catalog = [];
	var current = null;
	var qty = 1;
	var editing = null;
	var sheetMutating = false;
	var mode = cfg.defaultMode || 'takeaway';
	var ctx = {};
	var cartState = null;
	var cartMutating = false;
	var placing = false;
	var payReady = false;
	var payRequest = 0;
	var zoneRequest = 0;
	var zoneState = 'unknown';
	var checkoutStep = 'review';

	function esc(s) {
		return String(s == null ? '' : s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/"/g, '&quot;');
	}

	/* flavor-i18n-map: flavorData.i18n.menu */
	// All copy comes from flavorData.i18n.menu (Enqueue::menu_strings()). The
	// script holds no UI text of its own: Persian literals here would be copy no
	// site can translate, which is exactly what this file used to ship. A key
	// missing from the map surfaces as the key itself, and
	// tests/theme/test-js-i18n.php fails on that before a shopper can.
	var STR = (cfg.i18n && cfg.i18n.menu) || {};
	function t(key) {
		return typeof STR[key] === 'string' && STR[key] !== '' ? STR[key] : key;
	}
	// Substitution is positional and the caller escapes what it puts in when the
	// result lands inside markup; flavourToast/announce/textContent take plain text.
	function fill(key, value) { return t(key).replace('%s', value); }
	function fill2(key, first, second) { return t(key).replace('%1$s', first).replace('%2$s', second); }

	function headers(json) {
		var h = { 'X-WP-Nonce': cfg.nonce || '' };
		if (json) h['Content-Type'] = 'application/json';
		try {
			var token = sessionStorage.getItem('flavorCartToken');
			if (token) h['X-Cart-Token'] = token;
		} catch (ignore) { /* Cookies still support guests when storage is blocked. */ }
		return h;
	}

	function api(path, opt) {
		if (ui) return ui.request(path, opt);
		var options = Object.assign({ credentials: 'same-origin' }, opt || {});
		options.headers = Object.assign({}, headers(false), options.headers || {});
		return fetch(cfg.rest + path, options).then(function (r) {
			return r.json().then(function (j) {
				if (!r.ok || (j && j.success === false)) {
					var error = j && j.errors && j.errors[0];
					var msg = (error && error.message) || (j && (j.message || (j.data && j.data.message))) || r.statusText;
					throw new Error(msg);
				}
				// Core 1.4 uses an envelope; retained v1 store routes are raw.
				var data = j && j.success === true ? j.data : j;
				if (data && data.cart_token) {
					try { sessionStorage.setItem('flavorCartToken', data.cart_token); } catch (ignore) {}
				}
				return data;
			});
		});
	}

	function displayAmount(amount) {
		var money = cfg.currency || { storage: 'irr', display: 'irt' };
		var value = Number(amount) || 0;
		if (money.storage === 'irr' && money.display === 'irt') return Math.floor(value / 10);
		if (money.storage === 'irt' && money.display === 'irr') return value * 10;
		return value;
	}

	function normalizeDish(item, canonical) {
		var normalized = Object.assign({}, item);
		normalized.id = Number(item.id);
		normalized.short = item.short_desc || item.short || '';
		if (canonical) { normalized.storagePrice = Number(item.price) || 0; normalized.price = displayAmount(item.price); }
		if (Array.isArray(item.modifier_groups)) {
			normalized.groups = item.modifier_groups.map(function (group) { return Object.assign({}, group, { options: (group.options || []).map(function (option) { return Object.assign({}, option, { storagePrice: Number(option.price) || 0, price: displayAmount(option.price) }); }) }); });
			normalized.modifiers = [];
			item.modifier_groups.forEach(function (group) {
				(group.options || []).forEach(function (option) {
					normalized.modifiers.push(Object.assign({}, option, { type: group.type, price: displayAmount(option.price) }));
				});
			});
		}
		return normalized;
	}

	function showError(error) {
		if (window.flavorToast) window.flavorToast(error.message, 'error');
	}

	function fa(value) { return ui ? ui.digits(value) : String(value); }
	/* Grouping, digits and the currency word all come from the one spec the
	   server formats with (prompt 22) — see digits.js. t('currency') stays the
	   fallback so the price never loses its unit when the payload is thin. */
	function price(value) {
		var unit = (cfg.currency && cfg.currency.label) || t('currency');
		return window.FlavorDigits ? FlavorDigits.money(value, unit) : fa(String(value)) + ' ' + unit;
	}
	function safeImage(value) { try { var url = new URL(value, document.baseURI); return ['https:', 'http:'].includes(url.protocol) ? url.href : ''; } catch (ignore) { return ''; } }
	function plain(value) { var el = document.createElement('textarea'); el.innerHTML = String(value || '').replace(/<[^>]*>/g, ''); return el.value; }
	function smallIcon(name) { var path = name === 'clock' ? '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>' : '<path d="M12 5v14M5 12h14"/>'; return '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">' + path + '</svg>'; }
	// Same map the filter chips use, localized in PHP (UI::dietary_labels()).
	var dietLabels = cfg.dietaryLabels || {};
	function card(item) {
		var disabled = item.available === false;
		var image = safeImage(item.image);
		var cat = item.categories && item.categories[0];
		var name = esc(item.name);
		var media = image ? '<img src="' + esc(image) + '" alt="' + name + '" width="600" height="400" loading="lazy" decoding="async" />' : '<span class="flavor-food-card__placeholder">' + esc(t('no_image')) + '</span>';
		var metadata = (item.prep_time ? '<span class="flavor-food-card__meta-item">' + smallIcon('clock') + fill('prep_time', fa(item.prep_time)) + '</span>' : '');
		(item.dietary || []).slice(0, 1).forEach(function (flag) { if (dietLabels[flag]) metadata += '<span class="flavor-food-card__meta-item">' + esc(dietLabels[flag]) + '</span>'; });
		// The filter/sort layer and the wishlist metadata ride on the card itself,
		// so no second request is needed to answer "which of these is vegan?".
		var extra = ' data-dietary="' + esc((item.dietary || []).join(',')) + '"'
			+ ' data-allergens="' + esc((item.allergens || []).join(',')) + '"'
			+ ' data-prep="' + esc(item.prep_time || 0) + '"'
			+ ' data-calories="' + esc(item.calories || 0) + '"'
			+ ' data-price="' + esc(item.storagePrice || item.price || 0) + '"'
			+ ' data-url="' + esc(item.permalink || '') + '"';
		return '<article class="flavor-card flavor-food-card' + (disabled ? ' is-unavailable' : '') + '" id="item-' + esc(item.id) + '" data-id="' + esc(item.id) + '" data-name="' + name + '" data-cats="' + esc((item.categories || []).map(function (c) { return c.id; }).join(',')) + '"' + extra + '>' +
			'<div class="flavor-food-card__media"><button type="button" data-detail="' + esc(item.id) + '" aria-label="' + esc(fill('details', item.name)) + '">' + media + '</button>' + (cat ? '<span class="flavor-food-card__cat-badge">' + esc(cat.name) + '</span>' : '') + '</div>' +
			'<div class="flavor-food-card__body"><h2 class="flavor-food-card__title"><button type="button" data-detail="' + esc(item.id) + '">' + name + '</button>' + (disabled ? '<span class="flavor-food-card__unavailable">' + esc(t('unavailable')) + '</span>' : '') + '</h2><p class="flavor-food-card__desc">' + esc(item.short) + '</p>' +
			'<div class="flavor-food-card__meta">' + metadata + '</div><div class="flavor-food-card__footer"><strong class="flavor-food-card__price">' + esc(plain(item.price_html)) + '</strong><button type="button" class="flavor-btn flavor-btn--primary flavor-btn--sm" data-add="' + esc(item.id) + '" aria-label="' + esc(fill('choose', item.name)) + '"' + (disabled ? ' disabled' : '') + '>' + smallIcon('plus') + esc(t('choose_dish')) + '</button></div></div></article>';
	}

	function renderCats(cats) {
		if (!catsEl) return;
		var html = '<button type="button" class="is-active" data-cat="0" aria-pressed="true" aria-controls="flavor-menu-grid">' + esc(t('all_menu')) + ' <span class="flavor-cats__count">' + fa(catalog.length) + '</span></button>';
		(cats || []).forEach(function (c) {
			var count = catalog.filter(function (dish) { return (dish.categories || []).some(function (category) { return Number(category.id) === Number(c.id); }); }).length;
			if (count) html += '<button type="button" data-cat="' + esc(c.id) + '" aria-pressed="false" aria-controls="flavor-menu-grid">' + esc(c.name) + '<span class="flavor-cats__count">' + fa(count) + '</span></button>';
		});
		catsEl.innerHTML = html;
		var nav = document.getElementById('flavor-cats-nav'); if (nav) nav.hidden = false;
	}
	function filterCat(id) {
		var count = 0;
		grid.querySelectorAll('.flavor-card').forEach(function (el) { var visible = !id || id === '0' || (el.getAttribute('data-cats') || '').split(',').includes(String(id)); el.hidden = !visible; if (visible && !el.classList.contains('is-search-hidden')) count++; });
		if (catsEl) catsEl.querySelectorAll('button').forEach(function (button) { var selected = String(button.dataset.cat) === String(id || 0); button.classList.toggle('is-active', selected); button.setAttribute('aria-pressed', String(selected)); });
		if (statusEl) statusEl.textContent = fill('shown_count', fa(count));
	}

	function groupModifiers(mods) {
		var g = { size: [], topping: [], cook: [], removal: [] };
		(mods || []).forEach(function (m) {
			if (g[m.type]) g[m.type].push(m);
		});
		return g;
	}

	function livePrice() {
		if (!current) return 0;
		var canonical = current.storagePrice != null;
		var extra = 0;
		if (sheetBody) sheetBody.querySelectorAll('input:checked').forEach(function (input) { extra += Number(input.getAttribute(canonical ? 'data-storage-price' : 'data-price')) || 0; });
		var amount = ((canonical ? current.storagePrice : current.price) + extra) * qty;
		return canonical ? displayAmount(amount) : amount;
	}
	function setSheetError(message) {
		var error = document.getElementById('flavor-sheet-error');
		if (error) { error.hidden = !message; error.textContent = message || ''; }
	}
	function sheetSelectionValid() {
		return qty <= 20 && Array.from(sheetBody.querySelectorAll('[data-required="true"]')).every(function (group) { return !!group.querySelector('input:checked:not([value=""])'); });
	}
	function paintSheetPrice() {
		if (!sheetAdd || !current) return;
		var n = livePrice();
		var label = price(n);
		var price = document.getElementById('flavor-sheet-price'); if (price) price.textContent = label;
		var quantity = document.getElementById('flavor-qty'); if (quantity) quantity.textContent = fa(qty);
		var busy = sheetMutating || cartMutating;
		if (sheet) sheet.querySelectorAll('[data-q]').forEach(function (button) { button.disabled = busy || (button.dataset.q === '-1' && qty <= 1) || (button.dataset.q === '1' && qty >= 20); });
		sheetBody.querySelectorAll('input,textarea').forEach(function (field) { field.disabled = busy; });
		sheetAdd.disabled = busy || current.available === false || !sheetSelectionValid();
		sheetAdd.textContent = busy ? t('saving') : current.available === false ? t('choice_unavailable') : (editing ? t('save_changes') : t('add_to_cart')) + ' · ' + fill('unit_count', fa(qty));
		if (!sheetSelectionValid()) setSheetError(qty > 20 ? t('max_qty') : t('need_required'));
	}
	function openSheet(item, trigger, line) {
		if (!sheet || !sheetBody || !sheetTitle) { showError(new Error(t('no_sheet'))); return; }
		sheet.classList.toggle('flavor-sheet--cart-edit', !!line);
		current = item; editing = line || null; qty = line ? Math.max(1, Number(line.quantity) || 1) : 1;
		var existingIds = line ? (line.modifiers || []).map(function (option) { return String(option.id); }) : [];
		sheetTitle.textContent = item.name;
		var visual = document.getElementById('flavor-sheet-visual');
		var image = safeImage(item.image);
		if (visual) visual.innerHTML = (image ? '<img src="' + esc(image) + '" alt="' + esc(item.name) + '" width="700" height="700" />' : '') + '<p>' + smallIcon('clock') + esc(t('prep_note')) + '</p>';
		var html = (editing ? '<p class="flavor-ui-note">' + esc(t('edit_note')) + '</p>' : '') + '<p class="flavor-sheet__description">' + esc(plain(item.description || item.short)) + '</p><div class="flavor-sheet__metadata">' + (item.prep_time ? '<span class="flavor-ui-tag">' + smallIcon('clock') + fill('prep_time', fa(item.prep_time)) + '</span>' : '') + (item.calories ? '<span class="flavor-ui-tag">' + esc(fill('calories', fa(item.calories))) + '</span>' : '');
		(item.dietary || []).forEach(function (flag) { if (dietLabels[flag]) html += '<span class="flavor-ui-tag">' + esc(dietLabels[flag]) + '</span>'; });
		html += '</div>';
		var labels = { size: t('group_size'), topping: t('group_topping'), cook: t('group_cook'), removal: t('group_removal') };
		var groups = item.groups;
		if (!groups) { var g = groupModifiers(item.modifiers); groups = Object.keys(g).map(function (type) { return { type: type, multi: type === 'topping' || type === 'removal', required: type === 'size', options: g[type] }; }); }
		groups.forEach(function (group) {
			var list = group.options || []; if (!list.length) return;
			var firstDefault = list.findIndex(function (option) { return option.is_default; }); if (firstDefault < 0 && !group.multi && group.required) firstDefault = 0;
			html += '<fieldset class="flavor-sheet__fieldset" data-required="' + (!!group.required) + '"><legend>' + esc(labels[group.type] || group.title || t('group_choices')) + (group.required ? '<span class="flavor-ui-required"> ' + esc(t('required_suffix')) + '</span>' : '') + '</legend><div class="flavor-sheet__options">';
			if (!group.required && !group.multi) {
				var unchanged = line ? !list.some(function (option) { return existingIds.includes(String(option.id)); }) : firstDefault < 0;
				html += '<label class="flavor-sheet__option"><input type="radio" name="mod-' + esc(group.type) + '" value="" data-price="0" data-storage-price="0"' + (unchanged ? ' checked' : '') + ' /><span>' + esc(t('no_change')) + '</span><span class="flavor-sheet__option-price">' + esc(t('no_fee')) + '</span></label>';
			}
			list.forEach(function (option, index) {
				var checked = line ? existingIds.includes(String(option.id)) : group.multi ? !!option.is_default : index === firstDefault;
				html += '<label class="flavor-sheet__option"><input type="' + (group.multi ? 'checkbox' : 'radio') + '" name="mod-' + esc(group.type) + '" value="' + esc(option.id) + '" data-price="' + esc(option.price || 0) + '" data-storage-price="' + esc(option.storagePrice == null ? option.price || 0 : option.storagePrice) + '"' + (checked ? ' checked' : '') + ' /><span>' + esc(option.name) + '</span><span class="flavor-sheet__option-price">' + (option.price ? esc('+' + price(option.price)) : esc(t('no_fee'))) + '</span></label>';
			});
			html += '</div></fieldset>';
		});
		html += '<div class="flavor-ui-field"><label for="flavor-instr">' + esc(t('kitchen_note')) + ' <span class="flavor-ui-required">' + esc(t('optional')) + '</span></label><textarea id="flavor-instr" maxlength="200" rows="2" placeholder="' + esc(t('note_placeholder')) + '" aria-describedby="flavor-instr-help"></textarea><small id="flavor-instr-help">' + esc(t('note_help')) + '</small></div><p id="flavor-sheet-error" class="flavor-ui-error" role="alert" tabindex="-1" hidden></p>';
		sheetBody.innerHTML = html;
		if (line) document.getElementById('flavor-instr').value = line.instructions || '';
		paintSheetPrice();
		if (ui) ui.openDialog(sheet, trigger); else { sheet.hidden = false; document.body.style.overflow = 'hidden'; }
	}
	function closeSheet() { if (ui) ui.closeDialog(sheet); else { if (sheet) sheet.hidden = true; document.body.style.overflow = ''; } current = null; editing = null; resolvedFragment = ''; }

	function selectedIds() {
		var ids = [];
		if (!sheetBody) return ids;
		sheetBody.querySelectorAll('input:checked').forEach(function (inp) {
			if (inp.value) ids.push(inp.value);
		});
		return ids;
	}

	function addItem(item, ids, instr, q) {
		return api('cart/items', {
			method: 'POST',
			headers: headers(true),
			body: JSON.stringify({
				product_id: item.id,
				quantity: q || 1,
				modifier_ids: ids || [],
				instructions: instr || '',
			}),
		}).then(function (cart) {
			drawCart(cart);
			if (window.flavorToast) {
				window.flavorToast(fill('added_to_cart', item.name), 'success');
			}
			return cart;
		});
	}

	function setCartError(message) {
		var target = document.getElementById('flavor-cart-error'); if (target) { target.hidden = !message; target.textContent = message || ''; }
	}
	function readyCheckout() {
		var place = document.getElementById('flavor-place');
		if (place) place.disabled = placing || cartMutating || !payReady || !cartState || !cartState.count || !mode;
		var next = document.getElementById('flavor-cart-continue'); if (next) next.disabled = placing || cartMutating || !cartState || !cartState.count;
	}
	function step(next) {
		checkoutStep = next === 'checkout' ? 'checkout' : 'review';
		var review = document.getElementById('flavor-cart-review'); if (review) review.hidden = checkoutStep !== 'review';
		var checkout = document.getElementById('flavor-checkout'); if (checkout) checkout.hidden = checkoutStep !== 'checkout';
		var nextButton = document.getElementById('flavor-cart-continue'); if (nextButton) nextButton.hidden = checkoutStep !== 'review';
		var place = document.getElementById('flavor-place'); if (place) place.hidden = checkoutStep !== 'checkout';
		var back = document.getElementById('flavor-cart-back'); if (back) back.hidden = checkoutStep !== 'checkout';
		document.querySelectorAll('[data-ui-cart-step]').forEach(function (button) { if (button.dataset.uiCartStep === checkoutStep) button.setAttribute('aria-current', 'step'); else button.removeAttribute('aria-current'); });
		readyCheckout();
		if (cartPanel && !cartPanel.hidden) { var body = cartPanel.querySelector('.flavor-cart__body'); if (body) body.scrollTop = 0; var focus = checkoutStep === 'checkout' ? document.getElementById('flavor-name') : document.querySelector('[data-ui-cart-step="review"]'); if (focus) focus.focus({ preventScroll:true }); }
	}
	function drawCart(cart) {
		if (!cart) return;
		cartState = cart;
		if (cartCount) cartCount.textContent = String(cart.count || 0); // Legacy machine-readable count.
		if (mobileCartCount) mobileCartCount.textContent = fa(cart.count || 0);
		document.querySelectorAll('[data-ui-cart-count]').forEach(function (element) { element.textContent = fa(cart.count || 0); });
		document.querySelectorAll('[data-ui-cart-total]').forEach(function (element) { element.textContent = cart.count ? plain(cart.total_html) : t('cart_empty'); });
		var loading = document.getElementById('flavor-cart-loading'); if (loading) loading.hidden = true;
		var empty = document.getElementById('flavor-cart-empty'); if (empty) empty.hidden = !!cart.count;
		var filled = document.getElementById('flavor-cart-filled'); if (filled) filled.hidden = !cart.count;
		var actions = document.getElementById('flavor-cart-actions'); if (actions) actions.hidden = !cart.count;
		if (cartLines) {
			cartLines.innerHTML = (cart.items || []).map(function (item) {
				var mods = (Array.isArray(item.modifiers) ? item.modifiers : []).map(function (m) { return m.name + (Number(m.price) ? ' (' + fill('per_unit', '+' + price(displayAmount(m.price))) + ')' : ' (' + t('no_fee') + ')'); }).join(t('mod_separator') + ' ');
				var image = safeImage(item.image);
				var edit = cart.supports_item_edit ? '<button type="button" class="flavor-cart-line__edit" data-ui-cart-edit aria-haspopup="dialog" aria-controls="flavor-sheet" aria-label="' + esc(fill('edit_line_aria', item.name)) + '">' + esc(t('edit_line')) + '</button>' : '';
				return '<article class="flavor-cart-line" data-key="' + esc(item.key) + '">' + (image ? '<img class="flavor-cart-line__image" src="' + esc(image) + '" alt="" width="68" height="76" />' : '<span class="flavor-cart-line__image" aria-hidden="true"></span>') + '<div><h3>' + esc(item.name) + '</h3>' + (mods ? '<p>' + esc(mods) + '</p>' : '') + (item.instructions ? '<p>' + esc(fill('line_note', item.instructions)) + '</p>' : '') + edit + '<div class="flavor-cart-line__bottom"><div class="flavor-qty" role="group" aria-label="' + esc(fill('quantity_aria', item.name)) + '"><button type="button" data-ui-cart-qty="-1" aria-label="' + esc(fill('decrease_aria', item.name)) + '"' + (item.quantity <= 1 ? ' disabled' : '') + '>−</button><output>' + fa(item.quantity) + '</output><button type="button" data-ui-cart-qty="1" aria-label="' + esc(fill('increase_aria', item.name)) + '"' + (item.quantity >= 20 ? ' disabled' : '') + '>+</button></div><button type="button" class="flavor-cart-line__remove" data-rm="' + esc(item.key) + '" aria-label="' + esc(fill('remove_aria', item.name)) + '">' + esc(t('remove')) + '</button><strong class="flavor-cart-line__price">' + esc(plain(item.line_total_html || item.line_html)) + '</strong></div></div></article>';
			}).join('');
		}
		var sub = document.getElementById('flavor-cart-subtotal'); if (sub) sub.textContent = plain(cart.subtotal_html);
		if (cartTotal) cartTotal.textContent = plain(cart.total_html);
		[['discount', cart.discount_total, cart.discount_html], ['tax', cart.tax_total, cart.tax_html]].forEach(function (entry) {
			var row = document.getElementById('flavor-cart-' + entry[0] + '-row'); var value = document.getElementById('flavor-cart-' + entry[0]);
			if (row) row.hidden = !entry[1]; if (value) value.textContent = plain(entry[2]);
		});
		var fees = document.getElementById('flavor-cart-fees'); if (fees) fees.innerHTML = (cart.fees || []).map(function (fee) { return '<div><dt>' + esc(fee.name) + '</dt><dd>' + esc(plain(fee.amount_html || fee.html)) + '</dd></div>'; }).join('') + (cart.shipping_total ? '<div><dt>' + esc(t('shipping_row')) + '</dt><dd>' + esc(plain(cart.shipping_html)) + '</dd></div>' : '');
		var coupons = document.getElementById('flavor-coupon-applied'); if (coupons) coupons.innerHTML = (cart.coupons || []).map(function (code) { return '<button type="button" class="flavor-cart__coupon-remove" data-ui-remove-coupon>' + esc(fill('remove_coupon', code)) + '</button>'; }).join('');
		if (!cart.count) step('review');
		readyCheckout();
		// `subtotal` stays in storage units: the free-delivery bar compares it
		// against the shop's own threshold without re-parsing Persian numbers.
		window.flavorCartState = { count: Number(cart.count || 0), subtotal: Number(cart.subtotal || 0), subtotalHtml: plain(cart.subtotal_html), totalHtml: plain(cart.total_html) };
		document.dispatchEvent(new CustomEvent('flavor:cart-updated', { detail: { count: Number(cart.count || 0), total: plain(cart.total_html), subtotal: Number(cart.subtotal || 0), subtotalHtml: plain(cart.subtotal_html) } }));
	}
	function openCart(trigger) {
		if (!cartPanel) return;
		var toggle = document.getElementById('flavor-cart-toggle'); if (toggle) toggle.setAttribute('aria-expanded','true');
		if (ui) ui.openDialog(cartPanel, trigger); else cartPanel.hidden = false;
	}
	function closeCart() {
		if (ui) ui.closeDialog(cartPanel); else if (cartPanel) cartPanel.hidden = true;
		var toggle = document.getElementById('flavor-cart-toggle'); if (toggle) toggle.setAttribute('aria-expanded','false');
	}
	function mutateCart(route, options) {
		if (cartMutating || placing) return Promise.resolve();
		var focused = document.activeElement; var focusedRow = focused && focused.closest('[data-key]'); var focusedKey = focusedRow && focusedRow.dataset.key; var direction = focused && focused.dataset.uiCartQty;
		cartMutating = true; setCartError(''); readyCheckout();
		if (cartLines) { cartLines.setAttribute('aria-busy', 'true'); cartLines.querySelectorAll('button').forEach(function (button) { button.disabled = true; }); }
		return api(route, options).then(function (cart) { drawCart(cart); if (ui) ui.announce(fill('cart_updated', fa(cart.count))); return cart; }).catch(function (error) { setCartError(error.message); }).finally(function () { cartMutating = false; if (cartLines) cartLines.removeAttribute('aria-busy'); if (cartState) drawCart(cartState); readyCheckout(); if (focusedKey && cartPanel && !cartPanel.hidden) { var row = Array.from(cartLines.querySelectorAll('[data-key]')).find(function (entry) { return entry.dataset.key === focusedKey; }); var target = row && (direction ? row.querySelector('[data-ui-cart-qty="' + direction + '"]:not([disabled])') : row.querySelector('[data-rm]')); if (!target) target = document.getElementById('flavor-cart-close'); if (target) target.focus({ preventScroll:true }); } });
	}
	function setMode(next) {
		var allowed = Array.isArray(cfg.orderModes) ? cfg.orderModes : ['dine_in','takeaway','delivery'];
		mode = allowed.includes(next) ? next : allowed.includes(cfg.defaultMode) ? cfg.defaultMode : allowed.includes('takeaway') ? 'takeaway' : (allowed[0] || '');
		document.querySelectorAll('#flavor-modes [data-mode]').forEach(function (button) { button.hidden = !allowed.includes(button.dataset.mode); button.classList.toggle('is-active', button.dataset.mode === mode); button.setAttribute('aria-pressed', String(button.dataset.mode === mode)); });
		var tableBox = document.getElementById('flavor-table-box'); if (tableBox) tableBox.hidden = mode !== 'dine_in';
		var addressBox = document.getElementById('flavor-address-box'); if (addressBox) addressBox.hidden = mode !== 'delivery';
		['flavor-city','flavor-hood','flavor-line'].forEach(function (id) { var field = document.getElementById(id); if (field) field.required = mode === 'delivery'; });
		var table = document.getElementById('flavor-table'); if (table) table.required = mode === 'dine_in';
		zoneState = 'unknown'; ++zoneRequest;
		var row = document.getElementById('flavor-cart-zone-row'); if (row) row.hidden = true;
		var totalNote = document.getElementById('flavor-cart-total-note'); if (totalNote) totalNote.textContent = t('total_note');
		if (!mode) { setCartError(t('no_mode')); return; }
		api('context', { method:'POST', headers:headers(true), body:JSON.stringify({ order_mode:mode, branch_id:ctx.branch_id || cfg.branchId || 0 }) }).catch(function (error) { setCartError(error.message); });
		loadPay(); if (mode === 'dine_in') loadTables();
		if (mode === 'delivery' && document.getElementById('flavor-hood').value) checkZone();
		readyCheckout();
	}
	function loadPay() {
		var requestId = ++payRequest; var requestedMode = mode;
		payReady = false; readyCheckout();
		var box = document.getElementById('flavor-pay-box'); if (box) box.innerHTML = '<legend>' + esc(t('pay_methods')) + '</legend><p class="flavor-ui-note">' + esc(t('pay_loading')) + '</p>';
		api('checkout/options?mode=' + encodeURIComponent(mode) + '&branch_id=' + encodeURIComponent(ctx.branch_id || cfg.branchId || 0)).then(function (data) {
			if (requestId !== payRequest || requestedMode !== mode) return;
			payReady = !!(data.methods && data.methods.length);
			if (box) box.innerHTML = '<legend>' + esc(t('pay_methods')) + '</legend>' + (data.methods || []).map(function (method, i) { return '<label class="flavor-pay-option"><input type="radio" name="pay" value="' + esc(method.id) + '"' + (i === 0 ? ' checked' : '') + ' /><span>' + esc(method.title) + '</span></label>'; }).join('') + (payReady ? '' : '<p class="flavor-ui-note">' + esc(t('pay_none')) + '</p>');
			readyCheckout();
		}).catch(function (error) { if (requestId !== payRequest) return; payReady = false; if (box) box.innerHTML = '<legend>' + esc(t('pay_methods')) + '</legend><p class="flavor-ui-note">' + esc(t('pay_failed')) + '</p>'; setCartError(error.message); readyCheckout(); });
	}
	function loadTables() {
		api('branches/' + encodeURIComponent(ctx.branch_id || cfg.branchId || 0) + '/tables').then(function (rows) {
			var select = document.getElementById('flavor-table'); if (!select) return;
			select.innerHTML = '<option value="">' + esc(t('table_pick')) + '</option>' + (rows || []).map(function (table) { return '<option value="' + esc(table.id) + '" data-num="' + esc(table.table_number) + '"' + (String(table.id) === String(ctx.table_id || cfg.tableId || '') ? ' selected' : '') + '>' + esc(fill('table_number', fa(table.table_number))) + '</option>'; }).join('');
		}).catch(function (error) { setCartError(error.message); });
	}

	function dishDetail(item) {
		if (item.detailLoaded) return Promise.resolve(item);
		return api('dishes/' + item.id + '?branch_id=' + encodeURIComponent(cfg.branchId || 0)).then(function (detail) { var dish = normalizeDish(detail, true); dish.detailLoaded = true; return dish; });
	}

	var resolvedFragment = '';
	function openFragment() {
		// Opening a homepage product link must not silently add it to the cart.
		var match = /^#item-(\d+)$/.exec(window.location.hash);
		if (!match || resolvedFragment === window.location.hash) return;
		resolvedFragment = window.location.hash;
		var id = Number(match[1]);
		var item = catalog.find(function (dish) { return dish.id === id; });
		var detail = item ? dishDetail(item) : api('dishes/' + id).then(function (dish) { return normalizeDish(dish, true); });
		detail.then(function (dish) {
			if (dish.available === false) throw new Error(t('choice_gone'));
			var target = document.getElementById('item-' + id);
			if (target) { target.scrollIntoView({ block: 'center' }); var button = target.querySelector('[data-add]'); if (button) button.focus({ preventScroll: true }); }
			openSheet(dish, target && target.querySelector('[data-add]'));
		}).catch(showError);
	}
	window.addEventListener('hashchange', openFragment);
	window.FlavorMenuUI = { openProduct:function (id, trigger) { var item = catalog.find(function (dish) { return Number(dish.id) === Number(id); }); var details = item ? dishDetail(item) : api('dishes/' + Number(id)).then(function (dish) { return normalizeDish(dish, true); }); details.then(function (dish) { history.replaceState(null, '', '#item-' + Number(id)); resolvedFragment = location.hash; openSheet(dish, trigger); }).catch(showError); } };

	function loadMenu() {
		if (statusEl) statusEl.textContent = (cfg.i18n && cfg.i18n.loading) || '';
		grid.setAttribute('aria-busy', 'true');
		var retry = document.getElementById('flavor-menu-retry'); if (retry) retry.hidden = true;
		api('menu?per_page=100&branch_id=' + encodeURIComponent(cfg.branchId || 0)).then(function (data) {
			var canonical = Array.isArray(data);
			catalog = (canonical ? data : data.items || []).map(function (dish) { return normalizeDish(dish, canonical); });
			if (statusEl) statusEl.textContent = catalog.length ? '' : (cfg.i18n && cfg.i18n.empty) || '';
			grid.innerHTML = catalog.map(card).join('');
			grid.removeAttribute('aria-busy');
			if (statusEl) statusEl.textContent = fill('menu_count', fa(catalog.length));
			document.dispatchEvent(new CustomEvent('flavor:menu-ready'));
			var cats = canonical ? api('categories').then(function (rows) { return rows.filter(function (cat) { return cat.count > 0; }); }) : Promise.resolve(data.categories || []);
			cats.then(function (rows) {
				renderCats(rows);
				var requested = new URL(window.location.href).searchParams.get('cat');
				if (requested && Array.from(catsEl.querySelectorAll('button')).some(function (button) { return button.dataset.cat === requested; })) filterCat(requested);
			}).catch(showError);
			openFragment();
		}).catch(function (error) {
			grid.removeAttribute('aria-busy'); if (retry) retry.hidden = false;
			if (statusEl) statusEl.textContent = t('load_failed');
			showError(error);
		});
	}

	grid.addEventListener('click', function (e) {
		var button = e.target.closest('[data-add], [data-detail]');
		if (!button || button.disabled) return;
		var id = Number(button.getAttribute('data-add') || button.getAttribute('data-detail'));
		var item = catalog.find(function (dish) { return dish.id === id; });
		if (!item) return;
		button.disabled = true;
		dishDetail(item).then(function (dish) {
			openSheet(dish, button);
		}).catch(showError).finally(function () { button.disabled = false; });
	});

	if (sheet) {
		sheet.addEventListener('flavor:dialog-closed', function () { current = null; editing = null; resolvedFragment = ''; });
		sheet.addEventListener('click', function (e) {
			if (e.target.closest('[data-close="sheet"]')) closeSheet();
			var q = e.target.getAttribute('data-q');
			if (q) {
				if (sheetMutating || cartMutating) return;
				qty = Math.max(1, qty + parseInt(q, 10));
				var n = document.getElementById('flavor-qty');
				if (n) n.textContent = fa(qty);
				paintSheetPrice();
			}
		});
		sheet.addEventListener('change', function () { setSheetError(''); paintSheetPrice(); });
	}
	if (sheetAdd) {
		sheetAdd.addEventListener('click', function () {
			if (!current || sheetMutating || cartMutating || !sheetSelectionValid()) return;
			var target = current, line = editing;
			var instr = document.getElementById('flavor-instr');
			var body = { quantity: qty, modifier_ids: selectedIds(), instructions: instr ? instr.value : '' };
			sheetMutating = true; cartMutating = true; setSheetError(''); readyCheckout(); paintSheetPrice();
			var request = line ? api('cart/items/' + encodeURIComponent(line.key), { method:'PUT', headers:headers(true), body:JSON.stringify(body) }) : addItem(target, body.modifier_ids, body.instructions, body.quantity);
			request.then(function (cart) {
				if (line) drawCart(cart);
				if (current === target && editing === line) closeSheet();
				if (line && cartPanel && !cartPanel.hidden && sheet.hidden) {
					var row = Array.from(cartLines.querySelectorAll('[data-key]')).find(function (entry) { return entry.dataset.key === (cart.last_key || line.key); });
					var focus = row && row.querySelector('[data-ui-cart-edit]'); if (focus) focus.focus({ preventScroll:true });
				}
				if (ui) ui.announce(line ? t('choices_saved') : t('dish_added'));
			}).catch(function (error) {
				if (current === target && editing === line) { setSheetError(error.message); var feedback = document.getElementById('flavor-sheet-error'); if (feedback) feedback.focus({ preventScroll:true }); }
				else showError(error);
			}).finally(function () { sheetMutating = false; cartMutating = false; readyCheckout(); paintSheetPrice(); });
		});
	}

	if (catsEl) {
		catsEl.addEventListener('click', function (e) {
			var b = e.target.closest('[data-cat]');
			if (!b) return;
			catsEl.querySelectorAll('button').forEach(function (x) {
				x.classList.toggle('is-active', x === b);
			});
			filterCat(b.getAttribute('data-cat'));
		});
	}

	var toggle = document.getElementById('flavor-cart-toggle');
	if (cartPanel) cartPanel.addEventListener('flavor:dialog-closed', function () { if (toggle) toggle.setAttribute('aria-expanded','false'); });
	if (toggle && cartPanel) { toggle.hidden = false; toggle.addEventListener('click', function () { if (cartPanel.hidden) openCart(toggle); else closeCart(); }); }
	document.querySelectorAll('[data-ui-cart-close]').forEach(function (button) { button.addEventListener('click', closeCart); });
	document.querySelectorAll('[data-ui-cart-step]').forEach(function (button) { button.addEventListener('click', function () { if (cartState && cartState.count) step(button.dataset.uiCartStep); }); });
	var continueButton = document.getElementById('flavor-cart-continue'); if (continueButton) continueButton.addEventListener('click', function () { step('checkout'); });
	var backButton = document.getElementById('flavor-cart-back'); if (backButton) backButton.addEventListener('click', function () { step('review'); });
	if (cartLines) cartLines.addEventListener('click', function (event) {
		var row = event.target.closest('[data-key]'); if (!row || cartMutating || !cartState) return;
		var item = (cartState.items || []).find(function (line) { return line.key === row.dataset.key; }); if (!item) return;
		var edit = event.target.closest('[data-ui-cart-edit]');
		if (edit) {
			edit.disabled = true;
			dishDetail(catalog.find(function (dish) { return dish.id === Number(item.product_id); }) || { id: Number(item.product_id) }).then(function (dish) { openSheet(dish, edit, item); }).catch(function (error) { setCartError(error.message); }).finally(function () { edit.disabled = false; });
			return;
		}
		var remove = event.target.closest('[data-rm]'); var quantity = event.target.closest('[data-ui-cart-qty]');
		if (!remove && !quantity) return;
		var q = remove ? 0 : Math.max(1, Math.min(20, Number(item.quantity) + Number(quantity.dataset.uiCartQty)));
		mutateCart('cart/items/' + encodeURIComponent(item.key), { method:remove ? 'DELETE' : 'PUT', headers:headers(true), body:remove ? undefined : JSON.stringify({ quantity:q }) });
	});
	document.querySelectorAll('#flavor-modes [data-mode]').forEach(function (button) { button.addEventListener('click', function () { setMode(button.dataset.mode); }); });

	var hood = document.getElementById('flavor-hood');
	var city = document.getElementById('flavor-city');
	var zoneTimer;
	function invalidateZone() { zoneState = 'unknown'; ++zoneRequest; var row = document.getElementById('flavor-cart-zone-row'); if (row) row.hidden = true; }
	function checkZone() {
		if (mode !== 'delivery') return;
		var msg = document.getElementById('flavor-zone-msg');
		var requestId = ++zoneRequest;
		zoneState = 'pending'; if (msg) { msg.textContent = t('zone_checking'); msg.dataset.available = 'pending'; }
		api('zones/check', { method:'POST', headers:headers(true), body:JSON.stringify({ branch_id:ctx.branch_id || cfg.branchId || 0, neighborhood:hood ? hood.value.trim() : '', city:city ? city.value.trim() : '' }) }).then(function (zone) {
			if (requestId !== zoneRequest || mode !== 'delivery') return;
			zoneState = zone.ok ? 'yes' : 'no';
			if (msg) { msg.dataset.available = zoneState; msg.textContent = zone.ok ? fill2('zone_ok', plain(zone.delivery_fee_html), fa(zone.estimated_minutes)) : (zone.message || t('zone_out')); }
			var row = document.getElementById('flavor-cart-zone-row'); if (row) row.hidden = !zone.ok;
			var amount = document.getElementById('flavor-cart-zone'); if (amount) amount.textContent = plain(zone.delivery_fee_html);
			var note = document.getElementById('flavor-cart-total-note'); if (note) note.textContent = t('zone_note');
		}).catch(function (error) { if (requestId !== zoneRequest) return; zoneState = 'error'; if (msg) { msg.dataset.available = 'error'; msg.textContent = error.message; } });
	}
	[hood,city].forEach(function (field) { if (!field) return; field.addEventListener('input', function () { invalidateZone(); window.clearTimeout(zoneTimer); zoneTimer = window.setTimeout(checkZone, 450); }); field.addEventListener('change', function () { window.clearTimeout(zoneTimer); checkZone(); }); });
	var couponButton = document.getElementById('flavor-coupon-btn');
	if (couponButton) couponButton.addEventListener('click', function () {
		var field = document.getElementById('flavor-coupon'); var status = document.getElementById('flavor-coupon-status');
		if (!field || !field.value.trim()) { if (status) status.textContent = t('coupon_empty'); return; }
		couponButton.disabled = true;
		api('cart/coupon', { method:'POST', headers:headers(true), body:JSON.stringify({ code:field.value.trim() }) }).then(function (cart) { drawCart(cart); if (status) status.textContent = t('coupon_applied'); }).catch(function (error) { if (status) status.textContent = error.message; }).finally(function () { couponButton.disabled = false; });
	});
	var applied = document.getElementById('flavor-coupon-applied'); if (applied) applied.addEventListener('click', function (event) { if (event.target.closest('[data-ui-remove-coupon]')) mutateCart('cart/coupon', { method:'DELETE' }); });

	var form = document.getElementById('flavor-checkout');
	if (form) form.addEventListener('submit', function (event) {
		event.preventDefault(); if (!event.submitter || event.submitter.id !== 'flavor-place') { var confirmButton = document.getElementById('flavor-place'); if (confirmButton) confirmButton.focus(); return; } if (placing || cartMutating || !cartState || !cartState.count) return;
		var err = document.getElementById('flavor-checkout-err');
		function failure(message) { if (err) { err.hidden = false; err.textContent = message; err.focus({ preventScroll:true }); err.scrollIntoView({ block:'nearest' }); } }
		if (err) { err.hidden = true; err.textContent = ''; }
		var mobile = document.getElementById('flavor-mobile');
		if (mobile && !/^09\d{9}$/.test(ui ? ui.latin(mobile.value.trim()) : mobile.value.trim())) { failure(t('mobile_invalid')); mobile.focus(); return; }
		if (mode === 'delivery' && zoneState !== 'yes') { failure(t('zone_unconfirmed')); checkZone(); return; }
		var pay = form.querySelector('input[name="pay"]:checked'); if (!pay) { failure(t('pay_required')); return; }
		var table = document.getElementById('flavor-table'); var option = table && table.options[table.selectedIndex];
		placing = true; form.setAttribute('aria-busy','true'); readyCheckout();
		var button = document.getElementById('flavor-place'); if (button) button.textContent = t('placing');
		var token = ''; try { token = sessionStorage.getItem('flavorCartToken') || ''; } catch (ignore) {}
		api('checkout', { method:'POST', headers:headers(true), body:JSON.stringify({ order_mode:mode, branch_id:ctx.branch_id || cfg.branchId || 0, name:document.getElementById('flavor-name').value || '', mobile:ui ? ui.latin(mobile.value.trim()) : mobile.value, payment_method:pay.value, table_id:mode === 'dine_in' && table ? Number(table.value) : 0, table_number:mode === 'dine_in' && option ? option.dataset.num || '' : '', cart_token:token, address:{ city:city ? city.value.trim() : '', neighborhood:hood ? hood.value.trim() : '', line:document.getElementById('flavor-line').value.trim() } }) }).then(function (result) {
			if (result.redirect) { var url; try { url = new URL(result.redirect, location.href); } catch (ignore) {} if (!url || !['https:','http:'].includes(url.protocol)) throw new Error(t('bad_redirect')); window.location.href = url.href; return; }
			if (window.flavorToast) window.flavorToast(fill('order_placed', result.order_number || result.order_id || ''), 'success');
			drawCart({ items:[],count:0,total_html:'' });
		}).catch(function (error) { failure(error.message); /* Keep the cart and customer fields for recovery. */ }).finally(function () { placing = false; form.removeAttribute('aria-busy'); if (button) button.textContent = t('place_order'); readyCheckout(); });
	});

	Promise.all([api('context'), api('cart'), api('me')])
		.then(function (pair) {
			ctx = pair[0] || {};
			if (cfg.branchId) ctx.branch_id = Number(cfg.branchId);
			if (ctx.order_mode) mode = ctx.order_mode;
			drawCart(pair[1]);
			if (new URL(location.href).searchParams.get('open_cart') === '1') openCart(document.getElementById('flavor-cart-toggle'));
			var me = pair[2] || {};
			if (me.logged_in) {
				var n = document.getElementById('flavor-name');
				var m = document.getElementById('flavor-mobile');
				if (n && me.name) n.value = me.name;
				if (m && me.mobile) m.value = me.mobile;
			}
			setMode(mode);
		})
		.catch(function (error) {
			var loading = document.getElementById('flavor-cart-loading'); if (loading) loading.hidden = true;
			setCartError(fill('cart_fetch_failed', error.message));
			setMode(mode);
		});

	var reload = document.getElementById('flavor-menu-reload'); if (reload) reload.addEventListener('click', loadMenu);
	window.FlavorCartUI = { open:openCart, close:closeCart, state:function () { return cartState; } };
	loadMenu();
})();
